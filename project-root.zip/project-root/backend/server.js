const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

mongoose.connect('your_mongodb_connection_string', { useNewUrlParser: true, useUnifiedTopology: true });

const homeworkSchema = new mongoose.Schema({
  title: String,
  description: String,
  dueDate: Date,
});

const Homework = mongoose.model('Homework', homeworkSchema);

app.post('/homework', (req, res) => {
  const newHomework = new Homework(req.body);
  newHomework.save()
    .then(() => res.json('Homework added!'))
    .catch(err => res.status(400).json('Error: ' + err));
});

app.get('/homework', (req, res) => {
  Homework.find()
    .then(homework => res.json(homework))
    .catch(err => res.status(400).json('Error: ' + err));
});

app.listen(port, () => {
  console.log(`Server is running on port: ${port}`);
});