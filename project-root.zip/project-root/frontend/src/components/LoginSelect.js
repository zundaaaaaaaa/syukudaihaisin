import React from 'react';
import { useHistory } from 'react-router-dom';

function LoginSelect() {
  const history = useHistory();

  const handleStudentLogin = () => {
    history.push('/student');
  };

  const handleAdminLogin = () => {
    history.push('/admin-login');
  };

  return (
    <div>
      <h2>ログイン選択</h2>
      <button onClick={handleStudentLogin}>生徒用</button>
      <button onClick={handleAdminLogin}>管理者用</button>
    </div>
  );
}

export default LoginSelect;