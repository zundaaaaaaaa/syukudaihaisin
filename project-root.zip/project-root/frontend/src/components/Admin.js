import React, { useState } from 'react';
import axios from 'axios';

function Admin() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();

    const newHomework = {
      title,
      description,
      dueDate: new Date(dueDate)
    };

    axios.post('/homework', newHomework)
      .then(response => {
        console.log('Homework added:', response.data);
        // リセットフォーム
        setTitle('');
        setDescription('');
        setDueDate('');
      })
      .catch(error => console.error('Error adding homework:', error));
  };

  return (
    <div>
      <h2>新しい宿題の作成</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>タイトル:</label>
          <input type="text" value={title} onChange={e => setTitle(e.target.value)} required />
        </div>
        <div>
          <label>説明:</label>
          <textarea value={description} onChange={e => setDescription(e.target.value)} required></textarea>
        </div>
        <div>
          <label>提出期限:</label>
          <input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} required />
        </div>
        <button type="submit">配信</button>
      </form>
    </div>
  );
}

export default Admin;