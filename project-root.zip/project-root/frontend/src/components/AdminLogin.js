import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';

function AdminLogin() {
  const [password, setPassword] = useState('');
  const history = useHistory();

  const handleLogin = (event) => {
    event.preventDefault();
    if (password === 'moko0255') {
      history.push('/admin');
    } else {
      alert('パスワードが間違っています');
    }
  };

  return (
    <div>
      <h2>管理者ログイン</h2>
      <form onSubmit={handleLogin}>
        <div>
          <label>パスワード:</label>
          <input type="password" value={password} onChange={e => setPassword(e.target.value)} required />
        </div>
        <button type="submit">ログイン</button>
      </form>
    </div>
  );
}

export default AdminLogin;