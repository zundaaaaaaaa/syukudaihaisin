import React, { useEffect, useState } from 'react';
import axios from 'axios';

function Homework() {
  const [homework, setHomework] = useState([]);
  const [showDueDate, setShowDueDate] = useState(true);

  useEffect(() => {
    axios.get('/homework')
      .then(response => setHomework(response.data))
      .catch(error => console.error('Error fetching homework:', error));
  }, []);

  const toggleDueDate = () => {
    setShowDueDate(!showDueDate);
  };

  return (
    <div>
      <h2>宿題一覧</h2>
      <button onClick={toggleDueDate}>
        {showDueDate ? '期日を非表示' : '期日を表示'}
      </button>
      <ul>
        {homework.map(hw => (
          <li key={hw._id}>
            <h3>{hw.title}</h3>
            <p>{hw.description}</p>
            {showDueDate && <p>提出期限: {new Date(hw.dueDate).toLocaleDateString()}</p>}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Homework;