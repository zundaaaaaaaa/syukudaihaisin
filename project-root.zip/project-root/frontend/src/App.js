import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Home from './components/Home';
import LoginSelect from './components/LoginSelect';
import AdminLogin from './components/AdminLogin';
import Admin from './components/Admin';
import Homework from './components/Homework';

function App() {
  return (
    <Router>
      <Switch>
        <Route path="/" exact component={Home} />
        <Route path="/login-select" component={LoginSelect} />
        <Route path="/admin-login" component={AdminLogin} />
        <Route path="/admin" component={Admin} />
        <Route path="/student" component={Homework} />
      </Switch>
    </Router>
  );
}

export default App;